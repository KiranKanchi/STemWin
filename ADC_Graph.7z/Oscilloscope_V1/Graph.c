/*********************************************************************
*                SEGGER Microcontroller GmbH & Co. KG                *
*        Solutions for real time microcontroller applications        *
**********************************************************************
*                                                                    *
*        (c) 1996 - 2018  SEGGER Microcontroller GmbH & Co. KG       *
*                                                                    *
*        Internet: www.segger.com    Support:  support@segger.com    *
*                                                                    *
**********************************************************************

** emWin V5.46 - Graphical user interface for embedded applications **
All  Intellectual Property rights  in the Software belongs to  SEGGER.
emWin is protected by  international copyright laws.  Knowledge of the
source code may not be used to write a similar product.  This file may
only be used in accordance with the following terms:

The software has been licensed to  ARM LIMITED whose registered office
is situated at  110 Fulbourn Road,  Cambridge CB1 9NJ,  England solely
for  the  purposes  of  creating  libraries  for  ARM7, ARM9, Cortex-M
series,  and   Cortex-R4   processor-based  devices,  sublicensed  and
distributed as part of the  MDK-ARM  Professional  under the terms and
conditions  of  the   End  User  License  supplied  with  the  MDK-ARM
Professional. 
Full source code is available at: www.segger.com

We appreciate your understanding and fairness.
----------------------------------------------------------------------
Licensing information
Licensor:                 SEGGER Software GmbH
Licensed to:              ARM Ltd, 110 Fulbourn Road, CB1 9NJ Cambridge, UK
Licensed SEGGER software: emWin
License number:           GUI-00181
License model:            LES-SLA-20007, Agreement, effective since October 1st 2011 
Licensed product:         MDK-ARM Professional
Licensed platform:        ARM7/9, Cortex-M/R4
Licensed number of seats: -
----------------------------------------------------------------------
File        : example.c
Purpose     : Main program Template
---------------------------END-OF-HEADER------------------------------
*/

#include "main.h"
#include "GUI.h"

#include "dialog.h"
//extern int32_t ConvertedValue;

extern int val;
uint16_t dt;
FRAMEWIN_Handle hWin;
PROGBAR_Handle hPrb;
GRAPH_Handle hGra;
GRAPH_DATA_Handle hData;
//SLIDER_Handle hSlide;

#ifdef RTE_Compiler_EventRecorder
#include "EventRecorder.h"
#endif


static void wincallback(WM_MESSAGE* pMsg)
{
	GUI_RECT Rect;
		switch (pMsg->MsgId)
    {
    	case WM_PAINT:
				WM_GetInsideRect(&Rect);
				GUI_SetBkColor(GUI_BLUE);
				GUI_SetColor(GUI_YELLOW);
				GUI_ClearRectEx(&Rect);
				GUI_DrawRectEx(&Rect);
				GUI_SetFont(&GUI_Font8x16);
				GUI_DispStringHCenterAt("ADC Channel 3",400,50);
    		break;

    	default:
    		WM_DefaultProc(pMsg);
    }
}
// Main stack size must be multiple of 8 Bytes
#define APP_MAIN_STK_SZ (1024*10U)
uint64_t app_main_stk[APP_MAIN_STK_SZ / 8];
const osThreadAttr_t app_main_attr = {
  .stack_mem  = &app_main_stk[0],
  .stack_size = sizeof(app_main_stk)
};



/*----------------------------------------------------------------------------
 * Application main thread
 *---------------------------------------------------------------------------*/
__NO_RETURN void app_main (void *argument) {
	 
	
	GUI_Init();
	hWin = FRAMEWIN_Create("ADC on Keil RTX with SEGGER GUI- Kiran Kanchi",wincallback,WM_CF_SHOW,0,10,800,470);
	hPrb = PROGBAR_CreateEx(310,100,160,25,hWin,WM_CF_SHOW,0,0);
  hGra = GRAPH_CreateEx(90,150,600,220,hWin,WM_CF_SHOW,0,0);
	GRAPH_SetColor(hGra,GUI_BLACK,0);
	hData = GRAPH_DATA_YT_Create(GUI_YELLOW,600,0,1);
	GRAPH_AttachData(hGra,hData);
	GRAPH_SetGridVis(hGra, 1);
	//hSlide = SLIDER_CreateEx(350,420,160,25,hWin,WM_CF_ACTIVATE,0,0);
	while (1) {
		/*#ifdef RTE_Graphics_Touchscreen
		if(osOK)
		GUI_TOUCH_Exec();
		#endif
		
		*/
		PROGBAR_SetValue(hPrb,val/41);
		GRAPH_DATA_YT_AddValue(hData,val/20);
	//	dt = SLIDER_GetValue(hSlide);
		GUI_Exec();
		osDelay(50);
		GUI_X_ExecIdle();
    }
  } 

