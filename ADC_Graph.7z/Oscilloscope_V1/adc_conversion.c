#include <stdio.h>

#include "main.h"
#include "Board_LED.h"                  /* ::Board Support:LED */
#include "Board_Buttons.h"              /* ::Board Support:Buttons */
#include "Board_ADC.h"                  /* ::Board Support:A/D Converter */

#include "RTE_Components.h"             /* Component selection */
#include "stm32f7xx_hal.h"              // Keil::Device:STM32Cube HAL:Common

extern ADC_HandleTypeDef hadc3;
int val;
#ifdef RTE_Compiler_EventRecorder
#include "EventRecorder.h"
#endif

// Main stack size must be multiple of 8 Bytes
#define app_main2_stk_SZ (1024U)
uint64_t app_main2_stk[app_main2_stk_SZ / 8];
const osThreadAttr_t app_main2_attr = {
  .stack_mem  = &app_main2_stk[0],
  .stack_size = sizeof(app_main2_stk)
};



static osThreadId_t tid_adc_start;

__NO_RETURN static void adc_start(void *argument) {


  (void)argument;

  for (;;) {
			HAL_ADC_Start(&hadc3);
	//	HAL_ADC_PollForConversion(&hadc3,10);
		val = HAL_ADC_GetValue(&hadc3);	
		
  }

}

__NO_RETURN void app_main2 (void *argument) {
	
  (void)argument;
	tid_adc_start = osThreadNew(adc_start,NULL,NULL);
	for(;;)
	{}
}










